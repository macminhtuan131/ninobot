# Cách sử dụng gói bối cảnh Deep Research Nino

1. Copy toàn bộ phần prompt bắt đầu từ Bạn là trong PROMPT.md vào Deep Research.
2. Nếu ứng dụng không đọc ZIP, giải nén rồi upload riêng năm tài liệu ưu tiên:
   - docs/GOVERNOR_DESCRIPTIVE_SURVEY_2026-10-18.md
   - docs/governor_descriptive_survey_2026-10-18/analysis/report.json
   - docs/governor_descriptive_survey_2026-10-18/analysis/timing_summary.json
   - docs/CASTER_MECHANICAL_REFERENCE_2026-10-16.md
   - docs/FACTORY_FLOOR_CONTACT_LAB_2026-10-13.md
3. Các file code/config và tài liệu lịch sử còn lại dùng đối chiếu nếu cần.

Prompt tự chứa các số liệu chính, không yêu cầu đọc được workspace. Kết quả
18/10 ưu tiên hơn diễn giải trạng thái trong tài liệu 12–14/10. ROS wrapper
có default khác inline evaluator của survey: không trộn contract. H2 formal
chưa được chấm; ngưỡng 10%/+0,5 giây vẫn đề xuất. Phần thực đang chờ.

Bundle không chứa raw trace khoảng518 MB, checkpoint, database Optuna hoặc
STL meshes. URDF/SDF có mesh URI/path; không giả vờ đã mở geometry ngoài các
file thật sự truy cập được. Dùng nominal reference/audit cho số đo CAD đã
trích, giữ rõ số nào chưa được đo trên phần cứng.

SHA256.json ghi hash từng attachment; đây là bản chụp tài liệu phục vụ nghiên
cứu, không phải thí nghiệm mới hoặc authorization chạy robot/simulation.
