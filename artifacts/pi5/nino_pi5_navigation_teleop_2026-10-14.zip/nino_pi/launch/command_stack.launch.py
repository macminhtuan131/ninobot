"""Shared command pipeline; the physical motor/sensor bringup runs separately."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    params = LaunchConfiguration("control_params")
    return LaunchDescription([
        DeclareLaunchArgument("control_params",default_value=PathJoinSubstitution([
            FindPackageShare("nino_pi"),"config","control.yaml"])),
        Node(package="nino_pi",executable="command_gate",name="nino_command_gate",
             output="screen",parameters=[params,{"use_sim_time":False}]),
        Node(package="nav2_velocity_smoother",executable="velocity_smoother",name="velocity_smoother",
             output="screen",parameters=[params,{"use_sim_time":False}],
             remappings=[("cmd_vel","/cmd_vel_selected"),("cmd_vel_smoothed","/cmd_vel_smoothed")]),
        Node(package="nav2_collision_monitor",executable="collision_monitor",name="collision_monitor",
             output="screen",parameters=[params,{"use_sim_time":False}]),
        Node(package="nav2_lifecycle_manager",executable="lifecycle_manager",name="lifecycle_manager_commands",
             output="screen",parameters=[{"use_sim_time":False,"autostart":True,
                 "node_names":["velocity_smoother","collision_monitor"]}]),
    ])
