# GUI v4: thu dữ liệu bằng nút bấm

Hướng hiện hành: [motion contract → SysID → baseline → residual](../../docs/NINO_RESEARCH_DIRECTION_2026-11-03.md).
Mở trên laptop:

```bash
bash ~/ninorobot/src/nino_pi/scripts/mode_gui.sh
```

Thêm `--demo` để thử giao diện không SSH/ROS/motor; kết quả demo luôn Q0.
GUI không kết nối hoặc phát lệnh khi vừa mở. Điền `d@192.168.0.109` và SSH
key đã được cấp; IP có thể đổi. Các bước hiện ở tab **Thu dữ liệu thật**.
Không cần copy commands hay mở ba terminal. `--commands diagnostic` cũ mở
wizard này để tương thích; màn hình copy đã bỏ khỏi luồng chính.

| Nút | Tác dụng | Điều cần làm tiếp |
|---|---|---|
| 1 · Chuẩn bị | Copy runtime/hash qua SSH, không launch/flash/enable | Đợi DEPLOYED |
| 2a · Kết nối Agent/cảm biến | Chạy wrapper sensor đã đối chiếu hash nếu cổng trống; giữ driver đang dùng cổng, không kill/launch trùng | Sau reboot có thể bấm trước2b; không phát enable/vận tốc |
| 2b · Kiểm thiết bị | Audit driver/topic/owner, không phát command | Xem báo cáo; agent/bridge/LiDAR cần có dữ liệu; nút2a hỗ trợ wrapper đã review |
| 3 · Stack ZERO | Khởi động stack lệnh và kiểm lifecycle/zero/freshness | Giữ stack chạy; chưa enable motor |
| 4 · Thu60s | Metadata và recorder riêng; diagnostic chỉ1slot | Đợi RECORDING_READY, đã có samples ban đầu |
| 5 · Tiến2s | **Yêu cầu enable và tiến**, sau đó zero/disable | Quan sát xe, chờ recorder đủ60s và đóng |
| 6 · Kiểm raw | SQLite/metadata/hash/required channels, waveform nếu có | Đọc Q-level và các unknown |
| 7 · Lưu quan sát | Chọn tiến/tự dừng, không tiến, can thiệp hoặc chưa quan sát | Ghi trung thực, không suy từ encoder |
| 8 · Tải về | Copy nguyên raw và review vào `~/nino_real_data_imports/…` | Copy video camera riêng, đối chiếu sync |

Trước nút4 diagnostic: RC AUTO, sàn trống, cùng tải, video thấy bánh/thân/sàn;
ghi pose/caster (unknown được phép), sàn/tải, tên video/mốc đồng bộ. Nút5 chỉ
mở khi recorder ready trong cửa sổ đầu. Nếu chậm quá cửa sổ, không phát tiến
muộn hoặc tự kéo dài bag. Profile cố định0,05m/s, ramp0,10m/s², source2s.
Không sửa gain/current/monitor hoặc mở vật cản để làm xe chạy.

Chọn **Thu đứng yên** nếu chỉ cần recorder60s; không enable/tiến, không cần
stack lệnh. Những phiên độ lặp/SysID/vật cản/RL hiển thị kế hoạch nhưng khóa
motion vì chưa có protocol riêng. Một diagnostic mới không mở lại các pilot
cũ; thoát/mở GUI hoặc deploy lại cùng bundle không reset ledger.

## Quá trình, lỗi và đóng phiên

Bảng hiện mỗi process, mẫu ban đầu, remaining time, FORWARD, ZERO_DISABLED,
FINISHED và QC. **Trial complete không đồng nghĩa recorder FINISHED**.
Q2 chỉ xác nhận raw theo rubric; body/slip/physical stop/độ lặp chưa tự đạt.
GUI không auto promote Q3/Q4. Quan sát người vận hành không là GT định lượng.

Nút hủy/đóng cửa sổ yêu cầu đóng **trial → recorder → stack → sensor do GUI khởi động**, giữ ghi cho
finalizers. Heartbeat GUI mất sẽ yêu cầu đóng child trên Pi; SSH mất không
bảo đảm yêu cầu stop đã tới actuator. Dùng dừng vật lý khi cần, giữ nguồn Pi
cho recorder close. Không auto reconnect/retry/resume forward. Failures giữ
raw/log; closure không xác định giữ unknown và không bấm motion tiếp.

Local job journal: `~/.local/state/nino/collection_gui/`; Pi log:
`~/nino_runtime/collection_guided_20261103_v2/gui_jobs/`.
Runtime có source tracked ở `runtime/`, builder ở
`scripts/build_collection_runtime.py`. Cài bundle khác hash lên cùng namespace
bị từ chối để bảo toàn ledger; không xóa thư mục để thử lại. Không tự chấp nhận
GID phần cứng lạ; lỗi endpoint cần đối chiếu read-only.

## Chưa được xác nhận live trong lần sửa này

Offline/demo/fixture không chứng minh Pi có SSH, driver, scene hoặc endpoint
đang sẵn sàng. Firmware GUI authority nằm ở tab Advanced; **collector chính
không cần firmware đó và vẫn giữ RC AUTO**. Chưa flash, training, chạy Gazebo,
tăng tốc hoặc thu một phiên thật nào trong đợt sửa GUI này.

Nút2a dùng ba wrapper sensor đã review ở Pi và kiểm hash trước launch. Nếu file/cổng đổi thì báo lỗi để đối chiếu; không tự đoán mapping hoặc sửa firmware. Driver có sẵn được giữ nguyên khi GUI đóng; chỉ child do chính GUI khởi động được dừng.
