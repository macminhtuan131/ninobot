"""New residual experiment contract; deliberately incompatible with legacy torque PPO.

Backend adapters must explicitly implement this reference/observation contract.
This module does not launch Gazebo/ROS or train/deploy on import or preparation.
"""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
from nino_control.residual_velocity import CONTRACT_ID, FEATURES, SCALES, FeatureHistory, ReferenceLimits, ResidualReference, feature_frame


def experiment_contract(config):
    if config.get('experiment_contract') != CONTRACT_ID:
        raise ValueError('New residual velocity contract required; no legacy checkpoint conversion')
    if config.get('algorithm') not in ('TD3','PPO','SAC'):
        raise ValueError('Unsupported comparator')
    if config.get('actor',{}).get('privileged_inputs'):
        raise ValueError('Privileged actor input prohibited')
    k=config.get('actor',{}).get('history_frames',5)
    if type(k) is not int or k < 1:raise ValueError('Invalid history length')
    contract=dict(id=CONTRACT_ID,algorithm=config['algorithm'],features=list(FEATURES),
                  normalization_scales=list(SCALES),history_frames=k,observation_size=len(FEATURES)*k,
                  frame_order='oldest_to_newest',action=['normalized_common','normalized_diff'],
                  action_physical_units='wheel_linear_m_s',low_level='existing velocity backend; no additive effort',
                  replay_action='policy_proposal; reference projection belongs to environment transition',
                  configuration=deepcopy(config))
    body=json.dumps(contract,sort_keys=True,allow_nan=False)
    return dict(contract,sha256=hashlib.sha256(body.encode()).hexdigest())


def reward_terms(labels, weights, action, previous, dt):
    """Evaluation labels may be privileged sim truth; actor never receives them.

    Real matching metrics need an independently validated reference. A missing
    required label is unknown/error, never silently zero or encoder-derived GT.
    """
    if not math.isfinite(dt) or dt <= 0:raise ValueError('Invalid reward clock')
    required={name for name,w in weights.items() if w and name not in ('time','action_size','action_change')}
    if not required.issubset(labels):raise ValueError('Missing reward labels: '+str(sorted(required-set(labels))))
    if not all(math.isfinite(float(labels[name])) for name in required):raise ValueError('Nonfinite reward label')
    terms={}
    for name in required:
        value=float(labels[name])
        terms[name]=weights[name]*value if name=='progress_m' else -weights[name]*value*value*dt
    terms['time']=-weights.get('time',0.)*dt
    terms['action_size']=-weights.get('action_size',0.)*sum(x*x for x in action)*dt
    terms['action_change']=-weights.get('action_change',0.)*sum((a-b)**2 for a,b in zip(action,previous))/dt
    return sum(terms.values()),terms


def make_environment(config, backend):
    """Gym adapter around an explicitly verified backend, not legacy NinoGazeboEnv.

    backend.reset(seed)->(view,info), backend.advance_reference(v,w,dt)->
    (view,labels,terminated,truncated,info), backend.close(). Every view contains
    a body-frame deployable `features`, baseline (v,w), sample time, explicit
    permission/freshness/stop/fault flags and command receipt age.
    """
    contract=experiment_contract(config)
    if getattr(backend,'residual_contract_id',None) != CONTRACT_ID:
        raise ValueError('Backend reference adapter not validated for this contract')
    import gymnasium as gym
    from gymnasium import spaces
    import numpy as np
    class ResidualEnv(gym.Env):
        def __init__(self):
            self.action_space=spaces.Box(-1.,1.,shape=(2,),dtype=np.float32)
            self.observation_space=spaces.Box(-5.,5.,shape=(contract['observation_size'],),dtype=np.float32)
            self.limits=ReferenceLimits(**config['reference_limits'])
            self.reference=ResidualReference(self.limits)
            self.history=FeatureHistory(config['actor']['history_frames'],config['actor']['max_history_gap_s'])
            self.view=None;self.previous=(0.,0.)
        def observation(self,view):
            geometry=config['nominal_geometry']
            frame=feature_frame(view['features'],**geometry)
            return np.asarray(self.history.append(view['stamp_s'],frame),dtype=np.float32)
        def reset(self,*,seed=None,options=None):
            super().reset(seed=seed);self.history.clear();self.reference.reset();self.previous=(0.,0.)
            self.view,info=backend.reset(seed=seed)
            return self.observation(self.view),dict(info,experiment_contract=contract['sha256'])
        def step(self,action):
            proposed=tuple(float(x) for x in action)
            dt=float(config['control_interval_s']);view=self.view
            trace=self.reference.compose(view['baseline'],proposed,dt,config['simulation_authority'],
                permission=view['permission'],sensors_fresh=view['sensors_fresh'],history_ready=self.history.ready,
                command_age_s=view['command_age_s'],emergency_stop=view['emergency_stop'],fault=view['fault'])
            if self.reference.latched:
                backend.advance_reference(0.,0.,dt)
                raise RuntimeError('Residual reference stopped: '+trace['reason'])
            self.view,labels,terminated,truncated,info=backend.advance_reference(*trace['body_reference'],dt)
            # Override only action history with what THIS reference adapter requested.
            # Final ROS receipt and actual actuator target still come from backend.
            history=self.view['features']
            history['previous_proposal_common'],history['previous_proposal_diff']=proposed
            accepted=trace['accepted_reference_wheel_m_s'];nominal=trace['nominal_wheel_m_s']
            dl,dr=(a-b for a,b in zip(accepted,nominal))
            bound=self.limits.residual_wheel_m_s
            history['previous_accepted_common']=(dl+dr)/(2*bound)
            history['previous_accepted_diff']=(dr-dl)/(2*bound)
            value,terms=reward_terms(labels,config['reward_weights'],proposed,self.previous,dt)
            self.previous=proposed
            return self.observation(self.view),value,bool(terminated),bool(truncated),dict(info,
                policy_proposal=proposed,reference_trace=trace,reward_terms=terms,experiment_contract=contract['sha256'])
        def close(self):backend.close()
    return ResidualEnv()


def build_model(config, environment, seed):
    """Factory only; no .learn(). Gate must be changed by an explicit experiment protocol."""
    contract=experiment_contract(config)
    if config.get('training',{}).get('allowed') is not True:
        raise ValueError('Training is disabled: require backend validation, data/baseline gates and a new budget')
    training=config.get('training',{})
    if type(training.get('budget_transitions')) is not int or training['budget_transitions']<=0:
        raise ValueError('Explicit positive experiment budget required')
    if not training.get('backend_validation_artifact'):
        raise ValueError('Verified backend artifact required')
    validation=json.loads(Path(training['backend_validation_artifact']).read_text())
    if (validation.get('contract_id')!=CONTRACT_ID or validation.get('backend_validated') is not True
            or validation.get('features')!=list(FEATURES)
            or validation.get('history_frames')!=config['actor']['history_frames']):
        raise ValueError('Backend validation artifact does not match actor/reference contract')
    from stable_baselines3 import TD3,PPO,SAC
    import numpy as np
    if environment.observation_space.shape!=(contract['observation_size'],) or environment.action_space.shape!=(2,):
        raise ValueError('Environment observation/action contract mismatch')
    kwargs=deepcopy(config.get('algorithm_parameters',{}).get(config['algorithm'],{}))
    if config['algorithm']=='TD3':
        from stable_baselines3.common.noise import NormalActionNoise
        kwargs['action_noise']=NormalActionNoise(np.zeros(2),float(config.get('exploration_sigma',.1))*np.ones(2))
    model={'TD3':TD3,'PPO':PPO,'SAC':SAC}[config['algorithm']]('MlpPolicy',environment,seed=seed,**kwargs)
    model.nino_residual_contract=contract
    return model


def prepare_main(argv=None):
    import argparse
    from nino_rl.core import load_config
    p=argparse.ArgumentParser(description='Validate/write offline residual contract; never starts ROS or training')
    p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(argv);c=load_config(a.config);contract=experiment_contract(c)
    a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'contract.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2)+'\n')
    (a.output/'readiness.json').write_text(json.dumps(dict(software_prepared=True,training_released=False,
        hardware_residual_authority=0,backend_integration_verified=False,
        missing=['current hardware diagnostic/body reference','calibrated backend model','new sim adapter validation and experiment budget']),indent=2)+'\n')
    print('Prepared only:',a.output,'; no ROS, Gazebo, training or motor command started.')


if __name__=='__main__':prepare_main()
