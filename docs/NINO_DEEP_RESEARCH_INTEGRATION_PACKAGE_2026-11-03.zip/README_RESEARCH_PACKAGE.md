# Gói deep research Nino: tích hợp thực sự History / Governor / Residual TD3

## Cách dùng

1. Mở file prompt trong `docs/DEEP_RESEARCH_NINO_TICH_HOP_TD3_HISTORY_GOVERNOR_2026-11-03.md`, copy toàn bộ nội dung làm yêu cầu deep research.
2. Đính kèm gói này nếu công cụ đọc ZIP được. Nếu công cụ không đọc ZIP, giải nén rồi đính kèm các file ưu tiên ở mục15 của prompt; bắt đầu bằng các báo cáo hiện trạng và residual core/API/YAML.
3. Yêu cầu đọc manifest để phân biệt source current working tree, snapshot lịch sử, báo cáo ngoài và verification software. Ghi file không truy cập được; không giả vờ đọc cả gói.
4. Báo cáo trả về dùng để coding agent sửa file sau review. Gói không cấp quyền chạy hardware/simulation/training hoặc mở các budget đã đóng.

## Bằng chứng và phạm vi

- Snapshot project03/11/2026; real-data evidence được tổng hợp tới02/11. Working tree có sửa đổi chưa commit và untracked files; không đồng nghĩa đã deploy.
- TD3/History mới có code/config/test offline; chưa integration end-to-end mới được xác nhận.71 tests trong verification là kết quả đợt trước, không được chạy lại khi đóng gói prompt.
- Firmware source local không chứng minh flashed binary/mode/rate hiện tại.
- `pi_source_snapshot_2026_10_27/` là snapshot Pi lịch sử. Các update mounting/state sau đó nằm trong report; không coi snapshot là current Pi inventory.
- `external_reports/` là hai báo cáo người dùng cung cấp, có các giả định cần kiểm lại. Citation bên trong không tự là nguồn đã đọc.
- Không kèm raw bag/video, credentials/private SSH keys, toolchain, motor binaries hoặc trained checkpoints. Liên kết/path dẫn ra ngoài gói chưa được cung cấp. Không suy vì thiếu ở gói là chắc chắn không tồn tại ở nơi khác.
- Gói là tài liệu/source cho nghiên cứu, không là install/deploy bundle. Runtime resource ZIP và các dependency/source khác không kèm nếu manifest không kê; tests có thể yêu cầu thêm file nếu thực sự được chạy sau này.

## Mong muốn cốt lõi

Một kiến trúc đúng cơ chế + data/training/evaluation plan + ma trận sửa file + lát cắt tích hợp tối thiểu có bằng chứng. Có thể thay/giảm/bỏ TD3 hoặc governor nếu giải pháp đơn giản phù hợp hơn. Mỗi component phải có maturity/gate/stop rõ, tránh tạo thêm skeleton rồi gọi đã áp dụng.
