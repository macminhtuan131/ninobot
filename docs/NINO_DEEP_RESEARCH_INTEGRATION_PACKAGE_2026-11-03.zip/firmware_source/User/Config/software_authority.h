#ifndef NINO_SOFTWARE_AUTHORITY_H
#define NINO_SOFTWARE_AUTHORITY_H

#include <stdbool.h>
#include <stdint.h>
#include <math.h>

#define NINO_CONTROL_VERSION 1U
#define NINO_CONTROL_MAGIC 0x4E494E4FU
#define NINO_CONTROL_REQUEST_LEN 5U
#define NINO_CONTROL_STATE_LEN 20U
#define NINO_CONTROL_LEASE_MS 500U
#define NINO_CONTROL_COMMAND_MS 500U

enum { NINO_SOURCE_STOP=0U, NINO_SOURCE_RC=1U, NINO_SOURCE_ROS=2U };
enum { NINO_CLAIM=1U, NINO_HEARTBEAT=2U, NINO_SELECT=3U, NINO_ARM=4U,
       NINO_DISARM=5U, NINO_STOP=6U, NINO_CLEAR_STOP=7U, NINO_RELEASE=8U };
enum { NINO_OK=0U, NINO_BAD_REQUEST=1U, NINO_BUSY=2U, NINO_NOT_OWNER=3U,
       NINO_REPLAY=4U, NINO_NEED_ZERO=5U, NINO_RC_BLOCKED=6U,
       NINO_FEEDBACK_STALE=7U, NINO_STOP_LATCHED=8U, NINO_NO_SOURCE=9U };
enum { NINO_REASON_NONE=0U, NINO_REASON_BOOT=1U, NINO_REASON_DISARM=2U,
       NINO_REASON_SOURCE=3U, NINO_REASON_STOP=4U, NINO_REASON_LEASE=5U,
       NINO_REASON_COMMAND=6U, NINO_REASON_RC=7U, NINO_REASON_FEEDBACK=8U,
       NINO_REASON_INVALID=9U, NINO_REASON_RELEASE=10U };

typedef struct {
    uint8_t rc_online, rc_armed, rc_stop, rc_zero, feedback_mask;
} NinoControlInputs;

typedef struct {
    uint32_t owner, sequence, lease_tick, source, armed, latched, reason;
    uint32_t command_tick, command_seen, ack_client, ack_sequence, ack_result;
    float velocity, yaw;
} NinoAuthority;

static inline void nino_authority_init(NinoAuthority *s)
{
    *s=(NinoAuthority){0}; s->reason=NINO_REASON_BOOT;
}

static inline void nino_authority_disarm(NinoAuthority *s, uint32_t reason)
{
    s->armed=0U; s->command_seen=0U; s->velocity=0.0f; s->yaw=0.0f;
    s->reason=reason;
}

static inline void nino_authority_stop(NinoAuthority *s, uint32_t reason)
{
    nino_authority_disarm(s, reason); s->latched=1U;
}

static inline bool nino_authority_zero(const NinoAuthority *s, uint32_t now)
{
    return s->command_seen && (uint32_t)(now-s->command_tick)<=NINO_CONTROL_COMMAND_MS
        && isfinite(s->velocity) && isfinite(s->yaw)
        && s->velocity==0.0f && s->yaw==0.0f;
}

static inline bool nino_authority_rc_allowed(NinoControlInputs in)
{
    return in.rc_online && in.rc_armed && !in.rc_stop;
}

static inline void nino_authority_tick(NinoAuthority *s, uint32_t now,
                                      NinoControlInputs in)
{
    if (s->owner && (uint32_t)(now-s->lease_tick)>NINO_CONTROL_LEASE_MS) {
        nino_authority_stop(s,NINO_REASON_LEASE); s->source=NINO_SOURCE_STOP;
        s->owner=0U; s->sequence=0U;
    }
    if (!s->armed) return;
    if (in.feedback_mask!=3U) nino_authority_stop(s,NINO_REASON_FEEDBACK);
    else if (s->source==NINO_SOURCE_RC && !nino_authority_rc_allowed(in))
        nino_authority_stop(s,NINO_REASON_RC);
    else if (s->source==NINO_SOURCE_ROS && in.rc_online && (!in.rc_armed || in.rc_stop))
        nino_authority_stop(s,NINO_REASON_RC);
    else if (s->source==NINO_SOURCE_ROS &&
             (!s->command_seen || (uint32_t)(now-s->command_tick)>NINO_CONTROL_COMMAND_MS))
        nino_authority_stop(s,NINO_REASON_COMMAND);
}

static inline void nino_authority_command(NinoAuthority *s, uint32_t now,
                                         float v, float w)
{
    /* An arriving command must not revive a timed-out armed state. */
    if (s->armed && s->source==NINO_SOURCE_ROS && s->command_seen &&
        (uint32_t)(now-s->command_tick)>NINO_CONTROL_COMMAND_MS)
        nino_authority_stop(s,NINO_REASON_COMMAND);
    if (!isfinite(v) || !isfinite(w)) { nino_authority_stop(s,NINO_REASON_INVALID); return; }
    s->velocity=v; s->yaw=w; s->command_tick=now; s->command_seen=1U;
}

static inline uint32_t nino_authority_request(NinoAuthority *s, uint32_t now,
        const uint32_t q[NINO_CONTROL_REQUEST_LEN], NinoControlInputs in)
{
    nino_authority_tick(s,now,in);
    const uint32_t client=q[1], seq=q[2], op=q[3], arg=q[4];
    uint32_t result=NINO_OK;
    if (q[0]!=NINO_CONTROL_VERSION || client==0U || seq==0U ||
        op<NINO_CLAIM || op>NINO_RELEASE || (op!=NINO_SELECT && arg!=0U) ||
        (op==NINO_SELECT && arg>NINO_SOURCE_ROS)) result=NINO_BAD_REQUEST;
    else if (op==NINO_STOP || op==NINO_DISARM) {
        /* Stopping does not acquire somebody else's ownership. */
        if (op==NINO_STOP) nino_authority_stop(s,NINO_REASON_STOP);
        else nino_authority_disarm(s,NINO_REASON_DISARM);
        if (client==s->owner && (int32_t)(seq-s->sequence)>0) s->sequence=seq;
    }
    else if (op==NINO_CLAIM) {
        if (s->owner && s->owner!=client) result=NINO_BUSY;
        else if (s->owner==client && (int32_t)(seq-s->sequence)<=0) result=NINO_REPLAY;
        else {
            nino_authority_disarm(s,NINO_REASON_SOURCE);
            s->source=NINO_SOURCE_STOP; s->owner=client; s->sequence=seq; s->lease_tick=now;
        }
    }
    else if (s->owner!=client) result=NINO_NOT_OWNER;
    else if ((int32_t)(seq-s->sequence)<=0) result=NINO_REPLAY;
    else {
        s->sequence=seq;
        if (op==NINO_HEARTBEAT) s->lease_tick=now;
        else if (op==NINO_SELECT) {
            nino_authority_disarm(s,NINO_REASON_SOURCE); s->source=arg;
        }
        else if (op==NINO_RELEASE) {
            nino_authority_disarm(s,NINO_REASON_RELEASE); s->source=NINO_SOURCE_STOP;
            s->owner=0U; s->sequence=0U;
        }
        else if (op==NINO_CLEAR_STOP) {
            bool zero = s->source==NINO_SOURCE_RC ?
                (nino_authority_rc_allowed(in) && in.rc_zero) : nino_authority_zero(s,now);
            if (s->armed || !zero) result=NINO_NEED_ZERO;
            else { s->latched=0U; s->reason=NINO_REASON_DISARM; }
        }
        else if (op==NINO_ARM) {
            if (s->latched) result=NINO_STOP_LATCHED;
            else if (in.feedback_mask!=3U) result=NINO_FEEDBACK_STALE;
            else if (s->source==NINO_SOURCE_STOP) result=NINO_NO_SOURCE;
            else if (s->source==NINO_SOURCE_RC && !nino_authority_rc_allowed(in)) result=NINO_RC_BLOCKED;
            else if (s->source==NINO_SOURCE_ROS && in.rc_online && (!in.rc_armed || in.rc_stop)) result=NINO_RC_BLOCKED;
            else if (s->source==NINO_SOURCE_RC ? !in.rc_zero : !nino_authority_zero(s,now)) result=NINO_NEED_ZERO;
            else { s->armed=1U; s->reason=NINO_REASON_NONE; }
        }
    }
    /* Heartbeat cannot overwrite an operator command's acknowledgement. */
    if (op!=NINO_HEARTBEAT) {
        s->ack_client=client; s->ack_sequence=seq; s->ack_result=result;
    }
    return result;
}

static inline void nino_authority_status(const NinoAuthority *s, uint32_t now,
        NinoControlInputs in, uint32_t effective, uint32_t actuator_mode,
        uint32_t out[NINO_CONTROL_STATE_LEN])
{
    const uint32_t data[NINO_CONTROL_STATE_LEN]={
        NINO_CONTROL_VERSION,NINO_CONTROL_MAGIC,s->owner,s->sequence,s->source,
        s->armed,s->latched,s->reason,in.rc_online,in.rc_armed,in.rc_stop,in.feedback_mask,
        s->command_seen ? (uint32_t)(now-s->command_tick) : UINT32_MAX,
        s->owner ? (uint32_t)(now-s->lease_tick) : UINT32_MAX,
        s->ack_client,s->ack_sequence,s->ack_result,effective,actuator_mode,now};
    for (uint32_t i=0;i<NINO_CONTROL_STATE_LEN;i++) out[i]=data[i];
}
#endif
