#!/usr/bin/env bash
set -eo pipefail
nino_job_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$nino_job_root/tooling:$nino_job_root${PYTHONPATH:+:$PYTHONPATH}"
if [[ "${1:-}" != plan && "${1:-}" != status ]]; then
  source "$HOME/pi5-stm32-slam-main/scripts/env.sh"
  source "$HOME/nino_pi_ws/install/setup.bash"
  export ROS_DOMAIN_ID=0
  export PYTHONPATH="$nino_job_root/tooling:$nino_job_root${PYTHONPATH:+:$PYTHONPATH}"
fi
exec /usr/bin/python3 "$nino_job_root/session_cli.py" "$@"
